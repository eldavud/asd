
La Cosa Nostra – Bewerbung für eine Mafia-Fraktion auf German Fast Crimelife (FiveM)

1. Öffne das Projekt in einer React-Umgebung (z. B. mit Vite oder Next.js)
2. Lege die Bilder im Ordner /public/images/ ab:
   - lcn-logo.png (Logo der Fraktion)
   - gta-mafia-bg.jpg (Hintergrundbild mit GTA-Feeling)
3. Deploye das Projekt z. B. mit Vercel (https://vercel.com)

RP-Leader: El Davud
Discord: ElDavud#1930
